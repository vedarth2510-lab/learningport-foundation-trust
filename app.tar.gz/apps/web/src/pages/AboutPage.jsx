
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Shield, Target, Heart, Users, Lightbulb, Building2, Eye, FileText } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';

function AboutPage() {
  const coreValues = [
    { icon: Shield, title: 'Integrity', description: 'Maintaining transparency and ethical practices in all our operations' },
    { icon: Users, title: 'Empowerment', description: 'Enabling individuals to reach their full potential through education' },
    { icon: Heart, title: 'Equality', description: 'Ensuring equal opportunities for all, regardless of background' },
    { icon: Building2, title: 'Social Responsibility', description: 'Contributing to sustainable community development' },
    { icon: Lightbulb, title: 'Innovation', description: 'Adopting creative approaches to solve educational challenges' },
    { icon: Target, title: 'Community Development', description: 'Building stronger, self-reliant communities' },
    { icon: Eye, title: 'Transparency', description: 'Open communication about our activities and fund utilization' },
  ];

  return (
    <>
      <Helmet>
        <title>About Us - Learningport Foundation Trust</title>
        <meta name="description" content="Learn about Learningport Foundation Trust's mission, vision, values, and our commitment to empowering rural youth through education and skill development." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center max-w-3xl mx-auto"
              >
                <h1 className="mb-6">About Learningport Foundation Trust</h1>
                <p className="text-xl leading-relaxed">
                  A non-profit organization dedicated to transforming lives through education, skill development, and sustainable livelihood opportunities for rural youth across Karnataka.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-20 bg-background">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                >
                  <h2 className="mb-6">Why We Started</h2>
                  <p className="text-lg leading-relaxed mb-4">
                    Learningport Foundation Trust was founded with a clear vision: to bridge the educational and economic gap faced by rural youth in Karnataka. We recognized that talented young individuals in rural areas often lack access to quality education, skill training, and employment opportunities that could transform their lives.
                  </p>
                  <p className="text-lg leading-relaxed mb-4">
                    Our founders witnessed firsthand how limited resources and opportunities prevented bright students from reaching their potential. This inspired the creation of a foundation that would provide comprehensive support—from education and training to career guidance and placement assistance.
                  </p>
                  <p className="text-lg leading-relaxed">
                    Today, we work tirelessly to create pathways for rural youth to access quality education, develop marketable skills, and secure meaningful employment, thereby breaking the cycle of poverty and contributing to community development.
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                >
                  <img
                    src="https://images.unsplash.com/photo-1699271772975-a4cf35547d37"
                    alt="Women participating in empowerment programs"
                    className="rounded-2xl shadow-lg w-full"
                  />
                </motion.div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                  className="bg-primary/5 rounded-2xl p-8 border border-primary/20"
                >
                  <Eye className="h-12 w-12 text-primary mb-4" />
                  <h3 className="text-2xl font-semibold mb-4">Our Vision</h3>
                  <p className="text-lg leading-relaxed">
                    To create a society where every rural youth has access to quality education, skill development, and employment opportunities, enabling them to lead dignified and prosperous lives while contributing to community development.
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  viewport={{ once: true }}
                  className="bg-accent/5 rounded-2xl p-8 border border-accent/20"
                >
                  <Target className="h-12 w-12 text-accent mb-4" />
                  <h3 className="text-2xl font-semibold mb-4">Our Mission</h3>
                  <p className="text-lg leading-relaxed">
                    To empower rural youth through comprehensive education programs, vocational training, women empowerment initiatives, and career development support, while maintaining transparency and fostering sustainable community growth.
                  </p>
                </motion.div>
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
                className="mb-20"
              >
                <h2 className="text-center mb-12">Our Core Values</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {coreValues.map((value, index) => (
                    <motion.div
                      key={value.title}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <Card className="h-full hover:shadow-lg transition-all duration-300 rounded-2xl">
                        <CardContent className="p-6">
                          <value.icon className="h-10 w-10 text-primary mb-4" />
                          <h3 className="text-lg font-semibold mb-2">{value.title}</h3>
                          <p className="text-sm leading-relaxed text-muted-foreground">{value.description}</p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
                className="bg-muted rounded-2xl p-8"
              >
                <div className="flex items-start space-x-4 mb-6">
                  <FileText className="h-8 w-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h2 className="text-2xl font-semibold mb-4">Registration Details</h2>
                    <p className="text-lg leading-relaxed mb-6">
                      Learningport Foundation Trust is a registered non-profit organization committed to transparency and accountability in all our operations.
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <div className="flex justify-between py-2 border-b">
                      <span className="font-medium">Trust Registration Number</span>
                      <span className="font-mono">TR/BLR/2024/001234</span>
                    </div>
                    <div className="flex justify-between py-2 border-b">
                      <span className="font-medium">PAN</span>
                      <span className="font-mono">AAATL1234F</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between py-2 border-b">
                      <span className="font-medium">12A Registration</span>
                      <span className="font-mono">AAATL1234FE20241</span>
                    </div>
                    <div className="flex justify-between py-2 border-b">
                      <span className="font-medium">80G Registration</span>
                      <span className="font-mono">AAATL1234FF20242</span>
                    </div>
                  </div>
                </div>
                <div className="mt-6 p-4 bg-primary/5 rounded-lg border border-primary/20">
                  <p className="text-sm font-medium text-primary mb-2">CSR Eligibility</p>
                  <p className="text-sm">
                    Learningport Foundation Trust is eligible to receive CSR funds under Section 135 of the Companies Act, 2013. We align our programs with Schedule VII activities including education, skill development, and rural development.
                  </p>
                </div>
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default AboutPage;
