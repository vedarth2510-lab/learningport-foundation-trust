import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Users, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ImpactStatistics from '@/components/ImpactStatistics';
function HomePage() {
  return <>
      <Helmet>
        <title>Learningport Foundation Trust - Empowering Rural Youth Through Education</title>
        <meta name="description" content="Learningport Foundation Trust empowers rural youth through education, skill development, and employment opportunities in Karnataka, India." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 z-0">
              <img src="https://horizons-cdn.hostinger.com/1dc3209f-d186-4746-9ff9-033e69de3ec5/chatgpt-image-jun-1-2026-03_20_56-am-1-FVt5u.png" alt="Students learning together in a classroom" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40"></div>
            </div>

            <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.6
            }} className="max-w-3xl">
                <h1 className="text-white mb-6">
                  Empowering through education, skill development & employment opportunities
                </h1>
                <p className="text-xl text-white/90 leading-relaxed mb-8 max-w-2xl">
                  Building a brighter future for underserved communities across Karnataka through comprehensive education programs, vocational training, and sustainable livelihood initiatives.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link to="/donate">
                    <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground transition-all duration-200 active:scale-[0.98]">
                      <Heart className="mr-2 h-5 w-5" />
                      Donate Now
                    </Button>
                  </Link>
                  <Link to="/volunteer">
                    <Button size="lg" variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-white/30 backdrop-blur-sm transition-all duration-200 active:scale-[0.98]">
                      <Users className="mr-2 h-5 w-5" />
                      Volunteer With Us
                    </Button>
                  </Link>
                </div>
              </motion.div>
            </div>
          </section>

          <section className="py-20 bg-background">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.5
            }} viewport={{
              once: true
            }} className="text-center mb-12">
                <h2 className="mb-4">Our Impact</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Making a real difference in the lives of rural youth across Karnataka
                </p>
              </motion.div>

              <ImpactStatistics />
            </div>
          </section>

          <section className="py-20 bg-muted">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <motion.div initial={{
                opacity: 0,
                x: -20
              }} whileInView={{
                opacity: 1,
                x: 0
              }} transition={{
                duration: 0.5
              }} viewport={{
                once: true
              }}>
                  <h2 className="mb-6">Our Mission</h2>
                  <p className="text-lg leading-relaxed mb-6">
                    Learningport Foundation Trust is dedicated to creating sustainable change in rural communities by providing access to quality education, skill development programs, and employment opportunities.
                  </p>
                  <p className="text-lg leading-relaxed mb-8">
                    We believe that education is the foundation for breaking the cycle of poverty and creating lasting social impact. Through our comprehensive programs, we empower youth with the skills and knowledge they need to build successful careers and contribute to their communities.
                  </p>
                  <Link to="/about">
                    <Button variant="outline" className="group">
                      Learn More About Us
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                    </Button>
                  </Link>
                </motion.div>

                <motion.div initial={{
                opacity: 0,
                x: 20
              }} whileInView={{
                opacity: 1,
                x: 0
              }} transition={{
                duration: 0.5
              }} viewport={{
                once: true
              }} className="relative">
                  <img src="https://images.unsplash.com/photo-1573894998033-c0cef4ed722b" alt="Students participating in skill development training" className="rounded-2xl shadow-lg w-full" />
                </motion.div>
              </div>
            </div>
          </section>

          <section className="py-20 bg-background">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.5
            }} viewport={{
              once: true
            }} className="text-center mb-12">
                <h2 className="mb-4">How You Can Help</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Join us in our mission to transform lives through education and empowerment
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                <motion.div initial={{
                opacity: 0,
                y: 20
              }} whileInView={{
                opacity: 1,
                y: 0
              }} transition={{
                duration: 0.5,
                delay: 0.1
              }} viewport={{
                once: true
              }} className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-2xl p-8 border border-primary/20">
                  <Heart className="h-12 w-12 text-accent mb-4" />
                  <h3 className="text-xl font-semibold mb-3">Make a Donation</h3>
                  <p className="leading-relaxed mb-6">
                    Your contribution helps us provide education, training, and opportunities to deserving students. Every donation makes a difference.
                  </p>
                  <Link to="/donate">
                    <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground transition-all duration-200 active:scale-[0.98]">
                      Donate Now
                    </Button>
                  </Link>
                </motion.div>

                <motion.div initial={{
                opacity: 0,
                y: 20
              }} whileInView={{
                opacity: 1,
                y: 0
              }} transition={{
                duration: 0.5,
                delay: 0.2
              }} viewport={{
                once: true
              }} className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-2xl p-8 border border-primary/20">
                  <Users className="h-12 w-12 text-primary mb-4" />
                  <h3 className="text-xl font-semibold mb-3">Volunteer Your Time</h3>
                  <p className="leading-relaxed mb-6">
                    Share your skills and expertise to mentor students, conduct workshops, or support our programs in meaningful ways.
                  </p>
                  <Link to="/volunteer">
                    <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground transition-all duration-200 active:scale-[0.98]">
                      Become a Volunteer
                    </Button>
                  </Link>
                </motion.div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>;
}
export default HomePage;