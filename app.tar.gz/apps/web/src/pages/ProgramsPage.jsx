
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProgramCard from '@/components/ProgramCard';

function ProgramsPage() {
  const programs = [
    {
      name: 'Skill Development Programs',
      category: 'Training',
      objective: 'Equip rural youth with industry-relevant technical and soft skills to enhance employability',
      beneficiaries: 'Rural youth aged 18-30 seeking career opportunities',
      location: 'Bangalore and surrounding rural districts',
      beneficiaryCount: '1,247',
      image: 'https://images.unsplash.com/photo-1573894998033-c0cef4ed722b',
      successStory: 'Trained over 1,200 students in various technical skills with 73% placement rate',
    },
    {
      name: 'Cloud Computing Training',
      category: 'Technology',
      objective: 'Provide comprehensive training in cloud technologies (AWS, Azure, Google Cloud) to prepare students for IT careers',
      beneficiaries: 'Engineering graduates and diploma holders from rural areas',
      location: 'Bangalore training centers',
      beneficiaryCount: '487',
      image: 'https://images.unsplash.com/photo-1573894998033-c0cef4ed722b',
      successStory: 'Successfully placed 89% of cloud computing graduates in leading IT companies',
    },
    {
      name: 'Women Empowerment Initiatives',
      category: 'Empowerment',
      objective: 'Empower rural women through skill training, entrepreneurship development, and financial literacy',
      beneficiaries: 'Women from rural communities seeking economic independence',
      location: 'Rural villages across Karnataka',
      beneficiaryCount: '1,234',
      image: 'https://images.unsplash.com/photo-1699271772975-a4cf35547d37',
      successStory: 'Helped 1,234 women start their own businesses and achieve financial independence',
    },
    {
      name: 'Rural Student Support',
      category: 'Education',
      objective: 'Provide educational support, mentoring, and resources to students from rural backgrounds',
      beneficiaries: 'Students from government schools and rural colleges',
      location: 'Rural schools and colleges in Karnataka',
      beneficiaryCount: '2,847',
      image: 'https://images.unsplash.com/photo-1482858171642-11af2cffb404',
      successStory: 'Supported 2,847 students with educational resources and mentoring',
    },
    {
      name: 'Scholarship Programs',
      category: 'Financial Aid',
      objective: 'Provide financial assistance to deserving students from economically disadvantaged backgrounds',
      beneficiaries: 'Meritorious students unable to afford higher education',
      location: 'Across Karnataka',
      beneficiaryCount: '892',
      image: 'https://images.unsplash.com/photo-1482858171642-11af2cffb404',
      successStory: 'Awarded 892 scholarships enabling students to pursue higher education',
    },
    {
      name: 'Digital Literacy Programs',
      category: 'Technology',
      objective: 'Bridge the digital divide by teaching basic computer skills and internet literacy',
      beneficiaries: 'Rural youth and adults with limited digital exposure',
      location: 'Community centers in rural areas',
      beneficiaryCount: '1,567',
      image: 'https://images.unsplash.com/photo-1573894998033-c0cef4ed722b',
      successStory: 'Trained 1,567 individuals in basic computer and internet skills',
    },
    {
      name: 'Career Guidance Seminars',
      category: 'Counseling',
      objective: 'Provide career counseling and guidance to help students make informed career choices',
      beneficiaries: 'High school and college students from rural areas',
      location: 'Schools and colleges across Karnataka',
      beneficiaryCount: '3,421',
      image: 'https://images.unsplash.com/photo-1482858171642-11af2cffb404',
      successStory: 'Conducted career guidance sessions for 3,421 students',
    },
    {
      name: 'Internship & Placement Support',
      category: 'Employment',
      objective: 'Connect trained students with internship and job opportunities in reputed organizations',
      beneficiaries: 'Program graduates seeking employment',
      location: 'Bangalore and major cities',
      beneficiaryCount: '1,089',
      image: 'https://images.unsplash.com/photo-1573894998033-c0cef4ed722b',
      successStory: 'Facilitated internships and placements for 1,089 students',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Our Programs - Learningport Foundation Trust</title>
        <meta name="description" content="Explore our comprehensive programs including skill development, cloud computing training, women empowerment, scholarships, and career guidance for rural youth." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center max-w-3xl mx-auto"
              >
                <h1 className="mb-6">Our Programs</h1>
                <p className="text-xl leading-relaxed">
                  Comprehensive initiatives designed to empower rural youth through education, skill development, and sustainable livelihood opportunities.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-20 bg-background">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {programs.map((program, index) => (
                  <motion.div
                    key={program.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <ProgramCard program={program} />
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default ProgramsPage;
