
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import GalleryGrid from '@/components/GalleryGrid';

function GalleryPage() {
  const galleryImages = [
    {
      url: 'https://images.unsplash.com/photo-1679316481049-4f6549df499f',
      caption: 'Students participating in cloud computing training session',
    },
    {
      url: 'https://images.unsplash.com/photo-1641897434555-720ccf02fe35',
      caption: 'Certificate distribution ceremony for skill development program graduates',
    },
    {
      url: 'https://images.unsplash.com/photo-1671549213121-d28170cf3aa7',
      caption: 'Women empowerment workshop in rural Karnataka',
    },
    {
      url: 'https://images.unsplash.com/photo-1542957057-debadce4ce81',
      caption: 'Career guidance seminar for rural students',
    },
    {
      url: 'https://images.unsplash.com/photo-1573894998033-c0cef4ed722b',
      caption: 'Digital literacy training session in community center',
    },
    {
      url: 'https://images.unsplash.com/photo-1699271772975-a4cf35547d37',
      caption: 'Women entrepreneurs showcasing their products',
    },
    {
      url: 'https://images.unsplash.com/photo-1482858171642-11af2cffb404',
      caption: 'Scholarship award ceremony for deserving students',
    },
    {
      url: 'https://images.unsplash.com/photo-1679316481049-4f6549df499f',
      caption: 'Volunteer team conducting community outreach program',
    },
    {
      url: 'https://images.unsplash.com/photo-1641897434555-720ccf02fe35',
      caption: 'Students receiving hands-on technical training',
    },
    {
      url: 'https://images.unsplash.com/photo-1671549213121-d28170cf3aa7',
      caption: 'Blood donation camp organized by the foundation',
    },
    {
      url: 'https://images.unsplash.com/photo-1542957057-debadce4ce81',
      caption: 'Awareness campaign on education and skill development',
    },
    {
      url: 'https://images.unsplash.com/photo-1573894998033-c0cef4ed722b',
      caption: 'Internship placement drive for program graduates',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Gallery - Learningport Foundation Trust</title>
        <meta name="description" content="View photos from our events, training sessions, certificate distributions, seminars, and community outreach programs across Karnataka." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center max-w-3xl mx-auto"
              >
                <h1 className="mb-6">Gallery</h1>
                <p className="text-xl leading-relaxed">
                  Moments captured from our programs, events, and community initiatives that showcase the impact we're making together.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-20 bg-background">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
              >
                <GalleryGrid images={galleryImages} />
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}

export default GalleryPage;
